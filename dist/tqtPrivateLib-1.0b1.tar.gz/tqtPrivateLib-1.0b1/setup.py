from setuptools import setup
setup(
    name='tqtPrivateLib',
    version='1.0-beta.1',
    description='My first functions lib',
    author='Rear Admiral TQT',
    author_email='tuancr261@gmail.com',
    url='headfirstlabs.com',
    py_modules=['tqtPrivateLib']
)