an optional file for using setuptools package python 3.5
tqtPrivateLib module